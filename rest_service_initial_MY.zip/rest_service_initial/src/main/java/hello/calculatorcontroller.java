package hello;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/calculator")
public class calculatorcontroller {

    private final calculator calculator = new calculator();
    private final List<String> history = new ArrayList<>();

    @PostMapping("/add")
    public double add(@RequestParam double num1, @RequestParam double num2) {
        double result = calculator.add(num1, num2);
        history.add(num1 + " + " + num2 + " = " + result);
        return result;
    }

    @PostMapping("/subtract")
    public double subtract(@RequestParam double num1, @RequestParam double num2) {
        double result = calculator.subtract(num1, num2);
        history.add(num1 + " - " + num2 + " = " + result);
        return result;
    }

    @PostMapping("/multiply")
    public double multiply(@RequestParam double num1, @RequestParam double num2) {
        double result = calculator.multiply(num1, num2);
        history.add(num1 + " * " + num2 + " = " + result);
        return result;
    }

    @PostMapping("/divide")
    public double divide(@RequestParam double num1, @RequestParam double num2) {
        double result = calculator.divide(num1, num2);
        history.add(num1 + " / " + num2 + " = " + result);
        return result;
    }

    @GetMapping("/history")
    public List<String> getHistory() {
        return history;
    }

    @PostMapping("/clearHistory")
    public void clearHistory() {
        history.clear();
    }
}
